function HomePage(){
    return(
        <h2>Welcome to home</h2>
    );
   
}


export default HomePage;