function Footer() {
    return (
        <footer className="navbar  navbar-expand navbar-light bg-light fixed-bottom">


<div className="container-fluid justify-content-center">
                Group Members: Ayush Pokharel & Roshan Shrestha &  Benjamin Woosley 
            </div>


        </footer>
    );
}
export default Footer;